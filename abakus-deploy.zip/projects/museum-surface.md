---
layout: project.njk
title: Museum Surface
location: Berlin, Germany
year: 2024
type: cultural
images:
  - /img/museum-surface-1.jpg
  - /img/museum-surface-2.jpg
---

A cultural complex with layered concrete volumes.
