---
layout: project.njk
title: Villa Rock
location: Rock, Sweden
year: 2022
type: house
images:
  - /img/villa-rock-1.jpg
  - /img/villa-rock-2.jpg
---

A rock villa.
