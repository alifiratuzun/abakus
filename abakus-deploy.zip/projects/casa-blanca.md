---
layout: project.njk
title: Casa Blanca
location: Andalusia, Spain
year: 2022
type: house
images:
  - /img/casa-blanca-1.jpg
  - /img/casa-blanca-2.jpg
---

A pristine white home on a southern slope.